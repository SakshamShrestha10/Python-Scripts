A = input("Enter your name: ")

name1 = "Saksham"
name2 = "Smaran"

if A == name1:
    print("Saksham has RHCE certifcation")
elif A == name2:
    print("Smaran has no RHCE certification")
else:
    print("The name provided has no any certification")
