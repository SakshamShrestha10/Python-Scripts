name = input("Enter your name: ")
age = input("Enter your age: ")
role = input("Enter your role: ")

print("Hello " + name "!" "Welcome ")

