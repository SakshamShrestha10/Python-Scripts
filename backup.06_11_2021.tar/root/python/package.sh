!/bin/bash

packages="httpd vsftpd"

yum -y install $packages
